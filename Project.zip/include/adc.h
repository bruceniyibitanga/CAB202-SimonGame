#include "stdint.h"

void adc_init(void);
uint8_t adc_read(void);
uint16_t get_potentiometer_delay(void);