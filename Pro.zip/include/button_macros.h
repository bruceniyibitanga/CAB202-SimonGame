#include "avr/io.h"

#define S1 (1 << 4)
#define S2 (1 << 5)
#define S3 (1 << 6)
#define S4 (1 << 7)